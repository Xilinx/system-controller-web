from config_app import *

class Parse:
    def parse_cmd_resp(self, data, component):
        if(component == "getpower"):
            return self.parseGetPower(data)
        elif(component.startswith("list")):
            return self.parseList(data)
        elif(component == "getclock"):
            return self.parseGetClock(data)
        elif(component == "BIT"):
            return self.parseBit(data)

    def temperature(self,data):
        # Parse temperature data from data.
        pass

    def dashboard_eeprom(self,data):
        # Parse eeprom data for details
        pass

import json
class ParseData(Parse):
    def temperature(self,data):
        # Parse temperature data from data.
        temp = random.randrange(16,19)
        obj = json.loads(data)
        return {"temp":obj["ff0b0000ethernetffffffff00-mdio-0"]['temp1']['temp1_input']}

    def dashboard_eeprom(self,data):
        # Parse eeprom data for details
        ver = "" + app_config["major_version"]+"."+app_config["minor_version"]
        if app_config["deployment"] == "DEBUG":
            ver = ver + "." + app_config["dev_for_major_ver"]+"."+app_config["dev_minor_ver"] 
        resar = data.rstrip().split("\n")
        res = {"device":"-"
               ,"sil_rev":"-"
               ,"board_pn":"-"
               ,"rev":"-"
               ,"serial_number":"-"
               ,"mac1":"-"
               ,"mac2":"-"
               ,"appversion": ver
                }
        for re in resar:
            ary = re.split(":")
            if ary[0].startswith('Product'):
                res['device']=ary[1].strip()
            #if ary[0].startswith(''):
            #    res["sil_rev"].ary[1].strip()
            if ary[0].startswith('Board Part Number'):
                res["board_pn"]=ary[1].strip()
            if ary[0].startswith('Board Reversion'):
                res["rev"]=ary[1].strip()
            if ary[0].startswith('Board Serial Number'):
                res["serial_number"]=ary[1].strip()
            if ary[0].startswith('MAC Address 0'):
                res["mac1"]=re[re.index(":")+1:]
            if ary[0].startswith('MAC Address 1'):
                res["mac2"]=re[re.index(":")+1:]
        return res
    def parseGetPower(self,data):
        resar = data.rstrip().split("\n")
        res = {}
        for re in resar:
            ary = re.split(":")
            if ary[0].startswith('Voltage'):
                res["voltage"]=ary[1].strip()
            if ary[0].startswith('Current'):
                res["current"]=ary[1].strip()
            if ary[0].startswith('Power'):
                res["power"]=ary[1].strip()
        return res
    def parseBit(self,data):
        resar = data.strip().split(":")
        res = {}
        res["state"] = resar[1]
        res["message"] = data.strip()
        return res
    def parseGetClock(self,data):
        resar = data.strip().split(":")
        res = {}
        res["frequency"] = resar[1]
        return res
    def parseList(self,data):
        res = data.rstrip().split("\n")
        return res

import random
class ParseDataStatic(Parse):
    def temperature(self,data):
        # Parse temperature data from data.
        temp = random.randrange(16,19)
        return {"temp":temp}

    def dashboard_eeprom(self,data):
        # Parse eeprom data for details
        ver = "" + app_config["major_version"]+"."+app_config["minor_version"]
        if app_config["deployment"] == "DEBUG":
            ver = ver + "." + app_config["dev_for_major_ver"]+"."+app_config["dev_minor_ver"] 

        res = {"device":"VCK190"
               ,"sil_rev":"1.0"
               ,"board_pn":"0"
               ,"rev":"-"
               ,"serial_number":"abcd1234"
               ,"mac1":"0123456789"
               ,"mac2":"1234567890"
               ,"appversion": ver
                }
        return res
    def parseGetPower(self,data):
        res = {
            "power":4
            ,"voltage":1.9
            ,"current":2.5
        }
        return res
    def parseList(self,data):
        res = ["a","b","c"]
        return res
