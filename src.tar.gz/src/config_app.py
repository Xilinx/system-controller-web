

app_config = {
    "deployment":"DEBUG"              # RELEASE, DEBUG
    ,"major_version":"0"
    ,"minor_version" : "0"
    ,"dev_for_major_ver" : "α"
    ,"dev_minor_ver" : "001"
    ,"sc_app_path":"./sc_app"
    ,"sensors_app_path":"test"
    #,"sensors_app_path":"sensors"
    ,"config_sc_list_cmds":["listpower","listclock"]
    ,"config_bit_list_cmds":["listBIT"]
    ,"config_bm_list_cmds":["listbootmode"]
}

