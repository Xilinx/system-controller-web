/**
*   Spec to create json
*   top level tab creates left tab.
*   tab:    tabname
*   subtype:    tab or list.    -- Tab creates one tab at top of the screen under outer tab.
                                -- list creates screen for the particular div with all components
*   components:     a list of components with json object for each component described. can be a tab or list sub type.
*       subtype:    each component should contain subtype for the type of under lying objects
*       name:       equivalent to tab name. displays the name.
*       components: same as components at the top level. can be a list or tab.
*
*       objects under component can contain below items to display.
                    ,"components" : ["C,L0,V0,V1,V2,B0"]    // the order of keys to display in row.
                    ,"L0": "VCCINT"                         // c for checkbox
                    ,"V0": "- W"                            // L for label and 0 is label id
                    ,"V0V": "power"                         // V for value display label. 0 is label id
                    ,"V1" : "- V"                           // V*V stands for the key inside response obtained from ajax
                    ,"V1V": "voltage"                       //              = objectresponse.data[V*V]
                    ,"V1N": "V"                             // V*N stands for notation: V, W or amps etc
                    ,"V2": "- a"                            // B stands for button. 0 is button id.
                    ,"V2V": "current"                       //B*A : stands for request url.
                    ,"B0": "Get"                            // B0sc_cmd : stands for command type.
                    ,"B0A": "/cmdquery"                     // B0target : stands for target under the command type.
                    ,"B0sc_cmd":"getpower"                 // B0params : for additional parameters to send.
                    , "B0target":"vccint"
                    , "B0params":""
                    ,"E0": "configuration"                  // Edit field with key to send as parameter in ajay req.
                    ,"E0K": "W"                             // Notation of key. Not required.

*/
var listResponseDictionary = {
    "test":"a"
};
var boardsettingsTab = [];
var toplevelbstabjson = [
    "listpower"
    ,"listclock"
];
function requestLists(comp){
    return $.ajax({
                url: "cmdquery",
                type: 'GET',
                dataType: 'json',
                sync: false,
                data:{"sc_cmd":comp, "target":"", "params":""}
    });
}
function requestListsdummy(comp){

            // load the list and store in a dictionary for next use.
            var resData;
            $.ajax({

                success: function (res){
                    return res.data;
                },
                error: function(){
                }
            });
    return resData;
}
function addPowerTab(){
        var innComps = [];
        jQuery.each(listsjson_sc["listpower"] , function(i, tds){
        var eachcomp = {
            "type":"list"
            ,"components" : ["C,L0,V0,V1,V2,B0"]    // Checkbox, Label, editfield, info, button, Action
            ,"L0": tds
            ,"V0": "- mW"
            ,"V0N": "mW"
            ,"V0V": "power"
            ,"V1" : "- mV"
            ,"V1N": "mV"
            ,"V1V": "voltage"
            ,"V2": "- mA"
            ,"V2N": "mA"
            ,"V2V": "current"
            ,"B0": "Get"
            ,"B0A": "/cmdquery"
            ,"B0sc_cmd":"getpower"
            , "B0target": tds
            , "B0params":""
        };
        innComps.push(eachcomp);
    });
var headcomps = {
            "headcomponents":["C,L0,L1,L2,L3,B0"]
            ,"L0": "Rail Name"
            , "L1" : "Power"
            , "L2" : "Voltage"
            , "L3" : "Current"
            , "B0" : "Get All"
    }
    var dict = {"tab": "Power"
    ,"subtype":"tab"
        ,"components":[
            // Power :: get "use default configuration"
            {
            "subtype":"list"
            ,"name": "Use Default Calibration"
            ,"components": innComps
            , "headcomponents" : headcomps

            }
            // Power :: get "use custom configuration"
//            ,{
//            "subtype":"list",
//            "name": "Use Custom Calibration",
//            "components": [
//
//            ]
//            }
            ]
            };
    boardsettingsTab.push(dict);
}

function addClockTab(){
        var innCompsget = [];
        jQuery.each(listsjson_sc["listclock"] , function(i, tds){
        var eachcomp = {
            "type":"list"
            ,"components" : ["C,L0,V0,B0"]    // Checkbox, Label, editfield, info, button, Action
            ,"L0": tds
            ,"V0": "- Hz"
            ,"V0N": "Hz"
            ,"V0V": "frequency"
            ,"B0": "Get"
            ,"B0A": "/cmdquery"
            ,"B0sc_cmd":"getclock"
            , "B0target": tds
            , "B0params":""
        };
        innCompsget.push(eachcomp);
    });
     var innCompsset = [];
        jQuery.each(listsjson_sc["listclock"] , function(i, tds){
        var eachcomp = {
            "type":"list"
            ,"components" : ["C,L0,E0,B0"]    // Checkbox, Label, editfield, info, button, Action
            ,"L0": tds
            ,"E0": "value"
            ,"E0K": "-v"
            ,"B0": "Set"
            ,"B0A": "/cmdquery"
            ,"B0sc_cmd":"setclock"
            , "B0target": tds
            , "B0params":""
        };
        innCompsset.push(eachcomp);
    });

     var innCompsreset = [];
        jQuery.each(listsjson_sc["listclock"] , function(i, tds){
        var eachcomp = {
            "type":"list"
            ,"components" : ["C,L0,B0"]    // Checkbox, Label, editfield, info, button, Action
            ,"L0": tds
            ,"B0": "Restore"
            ,"B0A": "/cmdquery"
            ,"B0sc_cmd":"restoreclock"
            , "B0target": tds
            , "B0params":""
        };
        innCompsreset.push(eachcomp);
    });
    var headcompsget = {
            "headcomponents":["C,L0,L1,B0"]
            ,"L0": "Clock Name"
            , "L1" : "Frequency"
            , "B0" : "Get All"
    };
    var headcompsset = {
            "headcomponents":["C,L0,L1,B0"]
            ,"L0": "Clock Name"
            , "L1" : "Frequency"
            , "B0" : "Set All"
    };
    var headcompsreset = {
            "headcomponents":["C,L0,B0"]
            ,"L0": "Clock Name"
            , "B0" : "Restore All Clocks"
    };
    var dict = {"tab": "Clock"
    ,"subtype":"tab"
        ,"components":[
            {
            "subtype":"list"
            ,"name": "Get Clock"
            ,"components": innCompsget
            , "headcomponents" : headcompsget

            }
            ,{
            "subtype":"list"
            ,"name": "Set Clock"
            ,"components": innCompsset
            , "headcomponents" : headcompsset

            }
            ,{
            "subtype":"list"
            ,"name": "Restore Clock"
            ,"components": innCompsreset
            , "headcomponents" : headcompsreset
            }
            ]
            };
    boardsettingsTab.push(dict);
}
function generateBoardSettingsTabJSON(){

    addPowerTab();
    addClockTab();




}


var boardsettingsTabReference = [
// Clocks tab

//
//    {"tab": "Clocks"
//        ,"subtype":"tab"
//        ,"components":[{
//            "subtype":"list",
//            "name": "Set Clock",
//            "components": [
//                {
//                    "type":"list",
//                    "components" : ["C,L,E,I,BA"]  ,  // Checkbox, Label, editfield, info, button, Action
//                    "L": "zSFP Si570 Frequency",
//                    "E": "zSFP Si570 Frequency",
//                    "I" : "(Between 10 and 810 MHz)",
//                    "B": "Set Frequency",
//                    "A": "/getvoltage"
//                }
//            ]
//            }
//            ,{
//            "subtype":"list",
//            "name": "Read Clock",
//            "components": [
//                {
//                    "type":"list",
//                    "components" : ["CLEIB"]  ,
//                    "title": "zSFP Si570 Frequency",
//                    "info" : "(Between 10 and 810 MHz)",
//                    "buttonTitle": "Set Frequency"
//                }
//            ]
//            }
//            ,{
//            "subtype":"list",
//            "name": "Restore Clock",
//            "components": [
//                {
//                    "type":"list",
//                    "components" : ["CLEIB"]  ,
//                    "title": "zSFP Si570 Frequency",
//                    "info" : "(Between 10 and 810 MHz)",
//                    "buttonTitle": "Set Frequency"
//                }
//            ]
//            }
//        ]
//        }

// Voltages tab

//    , {"tab": "Voltages"
//    , "subtype":"list"
//    ,"components":[{
//
//                "components" : ["CLEIB"]  ,
//                "title": "zSFP Si570 Frequency",
//                "info" : "(Between 10 and 810 MHz)",
//                "buttonTitle": "Set Frequency"
//            }
//           ]
//    }

// Power Tab
    {"tab": "Power"
    ,"subtype":"tab"
        ,"components":[
            // Power :: get "use default configuration"
            {
            "subtype":"list"
            ,"name": "Use Default Calibration"
            ,"components": [
                {
                    "type":"list"
                    ,"components" : ["C,L0,V0,V1,V2,B0"]    // Checkbox, Label, editfield, info, button, Action
                    ,"L0": "VCCINT"
                    ,"V0": "- W"
                    ,"V0N": "W"
                    ,"V0V": "power"
                    ,"V1" : "- V"
                    ,"V1N": "V"
                    ,"V1V": "voltage"
                    ,"V2": "- a"
                    ,"V2N": "a"
                    ,"V2V": "current"
                    ,"B0": "Get"
                    ,"B0A": "/cmdquery"
                    ,"B0sc_cmd":"getpower"
                    , "B0target":"vccint"
                    , "B0params":""
                }
                ,{
                    "type":"list"
                    ,"components" : ["C,L0,V0,V1,V2,B0"]    // Checkbox, Label, editfield, info, button, Action
                    ,"L0": "VCCINT_SOC"
                    ,"V0": "- W"
                    ,"V0N": "W"
                    ,"V0V": "power"
                    ,"V1" : "- V"
                    ,"V1N": "V"
                    ,"V1V": "voltage"
                    ,"V2": "- a"
                    ,"V2N": "a"
                    ,"V2V": "current"
                    ,"B0": "Get"
                    ,"B0A": "/cmdquery"
                    ,"B0sc_cmd":"getpower"
                    , "B0target":"vccint_soc"
                    , "B0params":""
                }
                ,{
                    "type":"list"
                    ,"components" : ["C,L0,V0,V1,V2,B0"]    // Checkbox, Label, editfield, info, button, Action
                    ,"L0": "VCCINT_AUX"
                    ,"V0": "- W"
                    ,"V0N": "W"
                    ,"V0V": "power"
                    ,"V1" : "- V"
                    ,"V1N": "V"
                    ,"V1V": "voltage"
                    ,"V2": "- a"
                    ,"V2N": "a"
                    ,"V2V": "current"
                    ,"B0": "Get"
                    ,"B0A": "/cmdquery"
                    ,"B0sc_cmd":"getpower"
                    , "B0target":"vccint_aux"
                    , "B0params":""
                }
            ]
            }
            // Power :: get "use custom configuration"
            ,{
            "subtype":"list",
            "name": "Use Custom Calibration",
            "components": [

            ]
            }
            // Power :: get "INA226 Registers"
            ,{
            "subtype":"list",
            "name": "Get INA226 Registers",
            "components": [

            ]
            }
            // POWER :: Set ina 226 registers
            ,{
            "subtype":"list",
            "name": "Set INA226 Registers",
            "components": [
                {
                    "type":"list"
                    ,"components" : ["C,L0,E0,E1,E2,E3,B0"]    // Checkbox, Label, editfield, info, button, Action
                    ,"L0": "VCCINT"
                    ,"E0": "configuration"
                    ,"E0K": "W"
                    ,"E1" : "calibration"
                    ,"E1K": "V"
                    ,"E2": "mask_enable"
                    ,"E2K": "a"
                    ,"E3": "alert_limit"
                    ,"E3K": "a"
                    ,"B0": "Set"
                    ,"B0A": "/cmdquery"
                    ,"B0sc_cmd":"setpower"
                    , "B0target":"vccint"
                    , "B0params":""
                }
            ]
            }
        ]

    }
];
