var listsjson_bit = {
"listBIT":["Check Clocks","Check Voltage"]
}