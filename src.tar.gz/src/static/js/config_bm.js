function generateBootModeblock(){
	

}
